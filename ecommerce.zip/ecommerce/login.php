<?php
    session_start();
    include 'conecta.php';
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    $cripto = base64_encode($senha);
    
    
    $logar = mysqli_query($conn, "SELECT tb_pessoas.*,tb_usuarios.* FROM tb_pessoas,tb_usuarios where tb_pessoas.idpessoa = tb_usuarios.tb_pessoas_idpessoa and login='$login' AND senha='$cripto'");
    if(mysqli_num_rows($logar)>0){
        while($registro = $logar->fetch_array()){
        $_SESSION['login'] = $registro['login'];
        $_SESSION['inadmin'] = $registro['inadmin'];
        $_SESSION['nome'] = $registro['nome'];
        $_SESSION['idusuario'] = $registro['idusuario'];
        $_SESSION['logged_in'] = true;
        }
        include 'verifica.php';
    }
    else {
        unset($_SESSION['login']);
        echo "<script language='javascript' type='text/javascript'> 
          alert('Usuário ou senha inválido');
          window.location.href='entrar.php'
          </script>";
    }
?>